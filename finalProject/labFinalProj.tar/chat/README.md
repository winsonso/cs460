There are two program in this folder. They are included as tcp_server.py and tcp_client.py.
First, you need to run the server code in command line by typing
	python3 tcp_server.py

After you see the "Listening the port", you can open another terminal and run the command line as follow:
	python3 tcp_client.py


